<?php $__env->startSection('contenido'); ?>
<br>
<br>
<br>
<br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if(session('message')): ?>
            <div class="alert alert-<?php echo e(session('status')); ?>">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header"><?php echo e($variable); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('usuarios.configUpdate')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">Nombres</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(Auth::user()->name); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="surname" class="col-md-4 col-form-label text-md-right">Apellidos</label>

                            <div class="col-md-6">
                                <input id="surname" type="text" class="form-control<?php echo e($errors->has('surname') ? ' is-invalid' : ''); ?>" name="surname" value="<?php echo e(Auth::user()->surname); ?>" required>

                                <?php if($errors->has('surname')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('surname')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="telefono" class="col-md-4 col-form-label text-md-right">Telefono</label>

                            <div class="col-md-6">
                                <input id="telefono" type="tel" class="form-control<?php echo e($errors->has('telefono') ? ' is-invalid' : ''); ?>" name="telefono" value="<?php echo e(Auth::user()->telefono); ?>" required>

                                <?php if($errors->has('telefono')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('telefono')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="empresa" class="col-md-4 col-form-label text-md-right">Empresa</label>

                            <div class="col-md-6">
                                <input id="empresa" type="text" class="form-control<?php echo e($errors->has('empresa') ? ' is-invalid' : ''); ?>" name="empresa" value="<?php echo e(Auth::user()->empresa); ?>" required>

                                <?php if($errors->has('empresa')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('empresa')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">E-mail</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(Auth::user()->email); ?>" required>

                                <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <?php if(Auth::user()->imagen): ?>
                        <div class="form-group row">
                            <label for="imagen" class="col-md-4 col-form-label text-md-right">Tu Avatar</label>
                            <div class="col-md-6 avatar-config">
                                <img src="<?php echo e(Route('user.imagen', ['filename'=>Auth::user()->imagen])); ?>" alt="Avatar de <?php echo e(Auth::user()->name); ?> en Ramsa Security"/>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="form-group row">
                            <?php if(Auth::user()->imagen): ?>
                            <label for="imagen" class="col-md-4 col-form-label text-md-right">Deseas Cambiarlo?</label>
                            <?php else: ?>
                            <label for="imagen" class="col-md-4 col-form-label text-md-right">Tu Avatar</label>
                            <?php endif; ?>
                            <div class="col-md-6">

                                <input id="imagen" type="file" class="form-control<?php echo e($errors->has('imagen') ? ' is-invalid' : ''); ?>" name="imagen">

                                <?php if($errors->has('imagen')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('imagen')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Actualiza
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>