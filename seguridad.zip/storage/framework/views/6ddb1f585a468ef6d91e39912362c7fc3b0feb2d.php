<?php $__env->startSection('contenido'); ?>
<br>
<br>
<br>
<br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if(session('message')): ?>
            <div class="alert alert-<?php echo e(session('status')); ?>">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header"><?php echo e($variable); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('incidencia.guardar')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="cliente_id" class="col-md-4 col-form-label text-md-right">Empresa</label>

                            <div class="col-md-6">

                                <select id="cliente_id" class="form-control<?php echo e($errors->has('cliente_id') ? ' is-invalid' : ''); ?>" name="cliente_id"  required>
                                    <option value="<?php echo e(old('cliente_id')); ?>"><?php echo e(old('cliente_id')); ?></option>
                                    <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option value="0">No Hay</option>
                                    <?php endif; ?>
                                </select>
                                <?php if($errors->has('cliente_id')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('cliente_id')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="prioridad" class="col-md-4 col-form-label text-md-right">Prioridad</label>

                            <div class="col-md-6">

                                <select id="prioridad" class="form-control<?php echo e($errors->has('prioridad') ? ' is-invalid' : ''); ?>" name="prioridad"  required>
                                    <option value="<?php echo e(old('prioridad')); ?>"><?php echo e(old('prioridad')); ?></option>
                                    <option value="baja">Baja</option>
                                    <option value="media">Media</option>
                                    <option value="alta">Alta</option>
                                </select>
                                <?php if($errors->has('prioridad')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('prioridad')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="descripcion" class="col-md-4 col-form-label text-md-right">Descripcion</label>

                            <div class="col-md-6">
                                <textarea name="descripcion" id="descripcion" class="form-control<?php echo e($errors->has('descripcion') ? ' is-invalid' : ''); ?>" ><?php echo e(old('descripcion')); ?></textarea>
                                <?php if($errors->has('descripcion')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Crear Incidencia
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>