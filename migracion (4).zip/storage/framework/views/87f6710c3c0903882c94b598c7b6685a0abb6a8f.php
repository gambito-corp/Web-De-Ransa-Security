<?php $__env->startSection('contenido'); ?>
<h1><?php echo e($variable); ?></h1>
<br>
<div class="container-fluid">
    <?php if(session('message')): ?>
    <div class="alert alert-<?php echo e(session('status')); ?>">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>
    <br>
    <table id="Usuarios" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Rol</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Imagen</th>
                <th>Telefono</th>
                <th>Empresa</th>
                <th>E-mail</th>
                <th colspan="2">Acciones</th>
                <th>Creado en</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->role); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->surname); ?></td>
                <td>
                    <?php if($user->imagen): ?>
                    <img src="<?php echo e(Route('user.imagen', ['filename'=>$user->imagen])); ?>" alt="Avatar de <?php echo e($user->name); ?> en Ramsa Security" height="40"/>
                    <?php endif; ?>
                </td>
                <td><?php echo e($user->telefono); ?></td>
                <td><?php echo e($user->empresa); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><a class="tcb-small tcb-basic-d tcb-info" href="<?php echo e(route('usuarios.editar', ['id' =>$user->id])); ?>" target="_self"><span><i class="icon-eye-open"></i> Editar</span></a></td>
                <td>
                    <a href="#" class="tcb-small tcb-basic-d tcb-warning" data-toggle="modal" data-target="#modalScaleUp<?php echo e($user->id); ?>">Eliminar</a>

                    <div class="modal tc-modal tc-animation-scale-up" id="modalScaleUp<?php echo e($user->id); ?>">
                        <div class="modal-dialog ">
                            <div class="modal-content modal-padding">
                                <div class="modal-header">
                                    <i class="fa fa-close close" data-dismiss="modal"></i>
                                    <h4 class="modal-title">Alerta Estas Seguro que deseas eliminar a <?php echo e($user->name.' '.$user->surname); ?></h4>
                                </div>
                                <div class="modal-body">
                                    <p>Si lo eliminas No Hay marcha atras sera borrado de la Base de datos
                                        <br> y no se puede recuperar, no obstante si se puede volver a crear de nuevo</p>
                                </div>
                                <div class="modal-footer">
                                    <a href="#" class="tcb-small tcb-basic-d tcb-success" data-dismiss="modal">No Eliminar</a>
                                    <a href='<?php echo e(route('user.eliminar', ['id' =>$user->id])); ?> ' target='_self'  class="tcb-small tcb-basic-d tcb-danger">Eliminar Definitivamente</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td><?php echo e($user->created_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
            </tr>
            <?php endif; ?>

        </tbody>
        <tfoot>
            <tr>
                <th>ID</th>
                <th>Rol</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Imagen</th>
                <th>Telefono</th>
                <th>Empresa</th>
                <th>E-mail</th>
                <th colspan="2">Acciones</th>
                <th>Creado en</th>
            </tr>
        </tfoot>
    </table>
</div>
<script>
    $(document).ready(function() {
        $('#Usuarios').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>