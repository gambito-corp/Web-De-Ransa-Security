<?php $__env->startSection('contenido'); ?>
<br>
<br>
<br>
<br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if(session('message')): ?>
            <div class="alert alert-<?php echo e(session('status')); ?>">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header"><?php echo e($variable); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('testimonio.guardar')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="nombre" class="col-md-4 col-form-label text-md-right">Nombre</label>

                            <div class="col-md-6">
                                <input id="nombre" type="text" class="form-control<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="nombre" value="<?php echo e(old('nombre')); ?>" required autofocus>

                                <?php if($errors->has('nombre')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('nombre')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="empresa" class="col-md-4 col-form-label text-md-right">Empresa</label>

                            <div class="col-md-6">
                                <input id="empresa" type="text" class="form-control<?php echo e($errors->has('empresa') ? ' is-invalid' : ''); ?>" name="empresa" value="<?php echo e(old('empresa')); ?>" required autofocus>

                                <?php if($errors->has('empresa')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('empresa')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="descripcion" class="col-md-4 col-form-label text-md-right">Descripcion</label>

                            <div class="col-md-6">
                                <textarea name="descripcion" id="descripcion" class="form-control<?php echo e($errors->has('descripcion') ? ' is-invalid' : ''); ?>"><?php echo e(old('descripcion')); ?></textarea>
                                <?php if($errors->has('descripcion')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="cargo" class="col-md-4 col-form-label text-md-right">¿Que cargo Ostenta?</label>

                            <div class="col-md-6">
                                <input id="cargo" type="text" class="form-control<?php echo e($errors->has('cargo') ? ' is-invalid' : ''); ?>" name="cargo" value="<?php echo e(old('cargo')); ?>" required autofocus>

                                <?php if($errors->has('cargo')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('cargo')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">

                            <label for="imagen" class="col-md-4 col-form-label text-md-right">Logotipo de la Empresa</label>

                            <div class="col-md-6">

                                <input id="imagen" type="file" class="form-control<?php echo e($errors->has('imagen') ? ' is-invalid' : ''); ?>" name="imagen">

                                <?php if($errors->has('imagen')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('imagen')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="url_empresa" class="col-md-4 col-form-label text-md-right">URL de la Empresa</label>

                            <div class="col-md-6">
                                <input id="url_empresa" type="url" class="form-control<?php echo e($errors->has('url_empresa') ? ' is-invalid' : ''); ?>" name="url_empresa" placeholder="http://" value="<?php echo e(old('url_empresa')); ?>" required autofocus>

                                <?php if($errors->has('url_empresa')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('url_empresa')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Dar Testimonio
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>