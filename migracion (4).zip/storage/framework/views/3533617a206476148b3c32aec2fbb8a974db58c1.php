// esta es la vista del correo
// podemos usar etiquetas HTML

<h3>te contactaste con Ransa Security</h3>
<div>
    <?php echo e($mensaje); ?>

</div>
<p>sent via <?php echo e($correo); ?></p>
