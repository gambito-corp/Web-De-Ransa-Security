

<?php $__env->startSection('contenido'); ?>
<br>
<br>
<br>
<br>
<div class="container">
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galeria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-3 col-sm-6">
            <div class="tc-image-caption6">
                <?php if($galeria->imagen): ?>
                <img src="<?php echo e(Route('galeria.imagen', ['filename'=>$galeria->imagen])); ?>" alt="Imagen de <?php echo e($galeria->empresa); ?> en Ramsa Security" width="300"/>
                <?php endif; ?>
                <div class="caption">
                    <h3><?php echo e($galeria->titulo); ?></h3>
                    <p><?php echo e($galeria->descripcion); ?></p>
                </div>
                <div class="link-wrap">
                    <a href="#foto<?php echo e($galeria->id); ?>" data-toggle="modal" data-target="#foto<?php echo e($galeria->id); ?>"><i class="fa fa-search"></i></a>
                    <a href="#"><i class="fa fa-link"></i></a>
                </div>
            </div>
        </div>
        <div class="modal tc-modal fade" id="foto<?php echo e($galeria->id); ?>">
            <div class="modal-dialog">
                <div class="tc-image-caption6 modal-content">
                    <i class="fa fa-close close" data-dismiss="modal"></i>
                    <?php if($galeria->imagen): ?>

                    <img src="<?php echo e(Route('galeria.imagen', ['filename'=>$galeria->imagen])); ?>" alt="Imagen de <?php echo e($galeria->empresa); ?> en Ramsa Security" width="600"/>
                    <?php endif; ?>
                    <div class="caption">
                        <h3><?php echo e($galeria->titulo); ?></h3>
                        <p><?php echo e($galeria->descripcion); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-md-3 col-sm-6">
            <div class="tc-image-caption6">
                <img src="<?php echo e(asset('img/p6.jpg')); ?>" alt="imagen por default cuando esta vacia la tabla" width="300">
                <div class="caption">
                    <h3>No hay datos</h3>
                    <p>Suba una imagen a la web</p>
                </div>
                <div class="link-wrap">
                    <a href="#"><i class="fa fa-search"></i></a>
                    <a href="#"><i class="fa fa-link"></i></a>
                </div>
            </div>
        </div>

        <?php endif; ?>
    </div>
    <div class="clearfix"></div>
    <?php echo e($galerias->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>