<?php $__env->startSection('contenido'); ?>
<h1><?php echo e($variable); ?></h1>
<br>
<div class="container-fluid">
    <?php if(session('message')): ?>
    <div class="alert alert-<?php echo e(session('status')); ?>">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>
    <br>
    <br><br>
    <a href="<?php echo e(route('testimonio.crear')); ?>">Temporal Test Testimonios</a>
    <br>
    <table id="Testimonio" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre del creador</th>
                <th>Cargo</th>
                <th>Empresa</th>
                <th>Imagen</th>
                <th>Descripcion</th>
                <th>Url Empresa</th>
                <th>Aprobado</th>
                <th colspan="2">Acciones</th>
                <th>Creado en</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $testimonios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($testimonio->id); ?></td>

                <td><?php echo e($testimonio->nombre); ?></td>
                <td><?php echo e($testimonio->cargo); ?></td>
                <td><?php echo e($testimonio->empresa); ?></td>
                <td>
                    <?php if($testimonio->imagen): ?>
                    <img src="<?php echo e(Route('testimonio.imagen', ['filename'=>$testimonio->imagen])); ?>" alt="Imagen de <?php echo e($testimonio->empresa); ?> en Ramsa Security" height="100"/>
                    <?php endif; ?>
                </td>
                <td><?php echo e($testimonio->descripcion); ?></td>
                <td><?php echo e($testimonio->url_empresa); ?></td>
                <td><?php echo e($testimonio->aprobado); ?></td>
                <td><a class="tcb-small tcb-basic-d tcb-info" href="<?php echo e(route('testimonio.editar', ['id' => $testimonio->id])); ?>" target="_self"><span>Editar</span></a></td>
                <td>
                    <a href="#" class="tcb-small tcb-basic-d tcb-warning" data-toggle="modal" data-target="#modalScaleUp<?php echo e($testimonio->id); ?>">Eliminar</a>

                    <div class="modal tc-modal tc-animation-scale-up" id="modalScaleUp<?php echo e($testimonio->id); ?>">
                        <div class="modal-dialog ">
                            <div class="modal-content modal-padding">
                                <div class="modal-header">
                                    <i class="fa fa-close close" data-dismiss="modal"></i>
                                    <h4 class="modal-title">Alerta Estas Seguro que deseas eliminar el Testimonio de <?php echo e($testimonio->empresa); ?></h4>
                                </div>
                                <div class="modal-body">
                                    <p>Si lo eliminas No Hay marcha atras sera borrado de la Base de datos
                                        y no se puede recuperar,<br> no obstante si se puede volver a crear de nuevo</p>
                                </div>
                                <div class="modal-footer">
                                    <a href="#" class="tcb-small tcb-basic-d tcb-success" data-dismiss="modal">No Eliminar</a>
                                    <a href='<?php echo e(route('testimonio.eliminar', ['id' =>$testimonio->id])); ?> ' target='_self'  class="tcb-small tcb-basic-d tcb-danger">Eliminar Definitivamente</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td><?php echo e($testimonio->created_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
                <td>No hay</td>
            </tr>
            <?php endif; ?>

        </tbody>
        <tfoot>
            <tr>
                <th>ID</th>
                <th>Nombre del creador</th>
                <th>Cargo</th>
                <th>Empresa</th>
                <th>Imagen</th>
                <th>Descripcion</th>
                <th>Url Empresa</th>
                <th>Aprobado</th>
                <th colspan="2">Acciones</th>
                <th>Creado en</th>
            </tr>
        </tfoot>
    </table>
</div>
<script>
    $(document).ready(function() {
        $('#Testimonio').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>