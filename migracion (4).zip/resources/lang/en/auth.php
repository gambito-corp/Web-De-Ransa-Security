<?php

return [
    /*
      |--------------------------------------------------------------------------
      | Authentication Language Lines
      |--------------------------------------------------------------------------
      |
      | The following language lines are used during authentication for various
      | messages that we need to display to the user. You are free to modify
      | these language lines according to your application's requirements.
      |
     */

    'failed' => 'Este Usuario _No esta en los Registros, Porfavor Contacta con el WebMaster sfpraguirre@gambitocorp.com.',
    'throttle' => 'Has intentado loguearte en demasiadas ocasiones sin exito, porfavor intentalo de nuevo en  :seconds seconds.',
];
