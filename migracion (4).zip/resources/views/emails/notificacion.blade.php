// esta es la vista del correo
// podemos usar etiquetas HTML

<h3>te contactaste con Ransa Security</h3>
<div>
    {{$mensaje}}
</div>
<p>sent via {{$correo}}</p>
