
@extends('layouts.app')

@section('contenido')
<h1>{{$variable}}</h1>
<br>    
<div class="container">
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Rol</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>email</th>
                <th>Imagen</th>
            </tr>
        </thead>
        <tbody>
            @forelse($usuarios as $user)
            <tr>
                <td>{{$user->id}}</td>
                <td>System Architect</td>
                <td>{{$user->name}}</td>
                <td>61</td>
                <td>{{$user->email}}</td>
                <td>$320,800</td>
            </tr>
            @empty
            <tr>
                <td>No hay ID</td>
                <td>System Architect</td>
                <td>Edinburgh</td>
                <td>61</td>
                <td>2011/04/25</td>
                <td>$320,800</td>
            </tr>
            @endForelse
            
        </tbody>
        <tfoot>
            <tr>
                <th>ID</th>
                <th>Rol</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Telefono</th>
                <th>Imagen</th>
            </tr>
        </tfoot>
    </table>
    </div>
    <script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
@endsection
