<?php $__env->startSection('contenido'); ?>
<br>
<br>
<br>
<br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if(session('message')): ?>
            <div class="alert alert-<?php echo e(session('status')); ?>">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header"><?php echo e($variable); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('cliente.actualizado', ['id' => $cliente->id])); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="nombre" class="col-md-4 col-form-label text-md-right">Empresa</label>

                            <div class="col-md-6">
                                <input id="nombre" type="text" class="form-control<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="nombre" value="<?php echo e($cliente->nombre); ?>" required autofocus>

                                <?php if($errors->has('nombre')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('nombre')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="telefono" class="col-md-4 col-form-label text-md-right">Telefono</label>

                            <div class="col-md-6">
                                <input id="telefono" type="tel" class="form-control<?php echo e($errors->has('telefono') ? ' is-invalid' : ''); ?>" name="telefono" value="<?php echo e($cliente->telefono); ?>" required autofocus>

                                <?php if($errors->has('telefono')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('telefono')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Correo</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="http://" value="<?php echo e($cliente->email); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="cargo" class="col-md-4 col-form-label text-md-right">¿Que cargo Ostenta?</label>

                            <div class="col-md-6">
                                <input id="cargo" type="text" class="form-control<?php echo e($errors->has('cargo') ? ' is-invalid' : ''); ?>" name="cargo" value="<?php echo e($cliente->cargo); ?>" required autofocus>

                                <?php if($errors->has('cargo')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('cargo')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">

                            <label for="imagen" class="col-md-4 col-form-label text-md-right">Logotipo de la Empresa</label>

                            <div class="col-md-6">

                                <input id="imagen" type="file" class="form-control<?php echo e($errors->has('imagen') ? ' is-invalid' : ''); ?>" name="imagen">

                                <?php if($errors->has('imagen')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('imagen')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Actualizar Cliente
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>