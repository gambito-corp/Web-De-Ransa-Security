// esta es la vista del correo
// podemos usar etiquetas HTML

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>enviar correo</title>
</head>
<body>
    <h1>recibiste un mensaje</h1>
    <p>el cliente se llama <?php echo e($data['nombre']); ?></p>
    <p>quiere saber sobre <?php echo e($data['asunto']); ?></p>

    <p>te dejo este comentario: <br> <br> <?php echo e($data['mensaje']); ?></p>

    <p>contactate al correo: <?php echo e($data['correo']); ?></p>


    <br>
    <p>igual estos datos se guardaron en tu BD</p>

</body>
</html>