<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class Email extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */

    public $asu;
    public $men;
    public function __construct($asunto, $mensaje)
    {
        $this->asu = $asunto;
        $this->men = $mensaje;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {

        $e_asu = $this->asu;
        $e_men = $this->men;
        return $this->view('emails.notificacion', compact("e_men"))->subject($e_asu);
    }
}
