// esta es la vista del correo
// podemos usar etiquetas HTML

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>enviar correo</title>
</head>
<body>
    {{$e_men}}


</body>
</html>